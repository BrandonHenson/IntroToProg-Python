# open prepare ToDo.txt file
objFileName = "C:\PythonClass\Todo.txt"
objFile = open(objFileName,"r")
strData=""
dicTable={}
for line in objFile:
    lstData = line.split(",")
    dicTable[lstData[0].strip()]=lstData[1].strip()
objFile.close()
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    intChoice=int(input("Which Menu Item?"))
    if (intChoice == 1):
        for strKey, strValue in dicTable.items():
            print(strKey + ','+strValue)
        continue
    elif (intChoice==2):
        strTask=input("What is the new task?")
        strPriority=input("What is the priority?")
        dicTable[strTask]=strPriority
        for strKey, strValue in dicTable.items():
            print(strKey + ','+strValue)
        continue
    elif (intChoice == 3):
        for strKey, strValue in dicTable.items():
            print(strKey + ',' + strValue)
        strRemove=input("Which task should be removed?")
        if (strRemove in dicTable):
            del dicTable[strRemove]
            for strKey, strValue in dicTable.items():
                print(strKey + ',' + strValue)
        continue
    elif(intChoice == 4):
        objFile=open(objFileName,"w")
        for strKey, strValue in dicTable.items():
            objFile.write(strKey+","+strValue+"\n")
            #print("content="+strKey,"priority="+strValue)
        objFile.close()
        print("Your data saved to " + objFileName)
        continue
    elif(intChoice == 5):
        break
        exit()





