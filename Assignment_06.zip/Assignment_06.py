#-------------------------------------------------------------------------------
#Assignment 06
# Author: Brandon Henson
# Created: 02/15/18
#-------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------------  Data  ---------------------------------------------------------------------------------------------------------------------------#
objFileName = "C:\PythonClass\Todo.txt"
objFile = open(objFileName,"r")
strData=""
dicTable={}
#---------------------------------------------------------------------------------------------------  Processing  -----------------------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------  Class  --------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------  Functions  ------------------------------------------------------------------------------------------------------------------------#
class MyNewClass(object):
    @staticmethod
    def Menu():
#"This function will print out the menu for the user to choose from"
         print ("""
         Menu of Options
         1) Show current data
         2) Add a new item.
         3) Remove an existing item.
         4) Save Data to File
         5) Exit Program
         """)
         return
    @staticmethod
    def Display():
#"This function will print out the items in the dictionary"
        for strKey, strValue in dicTable.items():
            print(strKey + ',' + strValue)
        return
    @staticmethod
    def Add():
##"This function will allow the user to add a task and priority to the dictionary".
            strTask = input("What is the new task?")
            strPriority = input("What is the priority?")
            dicTable[strTask] = strPriority
            for strKey, strValue in dicTable.items():
                print(strKey + ',' + strValue)
            return
    @staticmethod
    def Remove():
##"This function will allow the user to remove a task from the dictionary".
            for strKey, strValue in dicTable.items():
                print(strKey + ',' + strValue)
            strRemove=input("Which task should be removed?")
            if (strRemove in dicTable):
                del dicTable[strRemove]
                for strKey, strValue in dicTable.items():
                    print(strKey + ',' + strValue)
            return
    @staticmethod
    def Save():
##"This function will allow the user to save the new file with the changes made".
            objFile=open(objFileName,"w")
            for strKey, strValue in dicTable.items():
                objFile.write(strKey+","+strValue+"\n")
            objFile.close()
            print("Your data saved to " + objFileName)
            return
    @staticmethod
    def Exit():
##"This function will allow the user to exit the program".
        exit()
    def LoadData():
##"This function will allow the user to load the data from the current dictionary".
        for line in objFile:
            lstData = line.split(",")
            dicTable[lstData[0].strip()] = lstData[1].strip()
        objFile.close()
        return
#-------------------------------------------------------------------------------------------------  Presentation  ----------------------------------------------------------------------------------------------------------------------#
MyNewClass.LoadData()
MyNewClass.Menu()
while(True):
    strVariable = input("What Menu Number Would You Like To Run? ")
    if strVariable=='1':
        MyNewClass.Display()
    elif strVariable =='2':
        MyNewClass.Add()
    elif strVariable=='3':
        MyNewClass.Remove()
    elif strVariable=='4':
        MyNewClass.Save()
    elif strVariable=='5':
        MyNewClass.Exit()
